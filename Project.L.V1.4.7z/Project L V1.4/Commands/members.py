import json
from typing import Any
import discord
from discord import app_commands, SelectOption
from discord.ext import commands, tasks
from discord.ui import Button, View, Select
import time
import os
import asyncio
import sqlite3
import datetime
import random
import traceback
import time
from discord.interactions import Interaction

conn = sqlite3.connect('sticky.db')
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS infos_salons (
        id_salon INTEGER PRIMARY KEY,
        contenu TEXT
    )
''')
conn.commit()
conn.close()

class MembersCommand(commands.Cog):
    def __init__(self, client):
        self.client = client


    def connect(self):
        try:
            conn = sqlite3.connect(f"Data/users.db")
            curs = conn.cursor()
            return conn, curs
        except Exception as exc:
            print(exc)
            return None


    # MODMAIL


    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author == self.client.user:
            return
        if message.author.avatar is None:
            userpfp = message.author.default_avatar
        else:
            userpfp = message.author.avatar
        try:
            catid = self.client.modmailid
            if str(message.channel.type) == "private":

                category = self.client.get_channel(catid)
                print(catid)
                print(category)
                if category is None:
                    return

                username = message.author
                for chan in category.channels:
                    if str(username).lower() in chan.name:
                        emb = discord.Embed(title="Mod Mail Reply", colour=discord.Colour.green())
                        emb.set_author(name=message.author, icon_url=userpfp)
                        emb.add_field(name="Original Message", value=message.content, inline=False)

                        await chan.send(
                            content=f"{message.author.mention}\n\n{message.content}",
                            embed=emb,
                            files=[await attachment.to_file() for attachment in message.attachments]
                        )
                        return

                class DeleteView(discord.ui.View):
                    def __init__(self):
                        super().__init__(timeout=None)
                        self.add_item(
                            discord.ui.Button(
                                emoji="🗑️",
                                style=discord.ButtonStyle.grey,
                                custom_id=f"modmail_del",
                                disabled=False
                            )
                        )

                chan = await category.guild.create_text_channel(name=f"{username}", category=category)
                emb = discord.Embed(title="New Mod Mail", colour=discord.Colour.blue())
                emb.set_author(name=message.author, icon_url=userpfp)
                emb.add_field(name="Message Content", value=message.content, inline=False)
                message_to_pin = await chan.send(
                    content=f"{message.author.mention}\n\n{message.content}",
                    embed=emb,
                    files=[await attachment.to_file() for attachment in message.attachments],
                    view=DeleteView()
                )
                await message_to_pin.pin()
                return

                await chan.send(
                    content=f"{message.author.mention}\n\n{message.content}",
                    files=[await attachment.to_file() for attachment in message.attachments]
                )
                return

            if message.channel.category_id == catid:
                async for msg in message.channel.history(limit=None, oldest_first=False):
                    if msg.author == self.client.user:
                        if len(msg.content) > 0:
                            authorid = int(msg.content.split(">")[0].replace("<", "").replace("@", "").replace("!", ""))
                            author = message.guild.get_member(authorid)
                            if not author:
                                return

                            # Allow users to send pictures via DM to the mod mail channel
                            if message.attachments:
                                for attachment in message.attachments:
                                    # Use await when calling to_file() method
                                    await author.send(
                                        content=f"{message.author.mention}\n\n{message.content}",
                                        files=[await attachment.to_file()]
                                    )
                            else:
                                await author.send(content=f"{message.author.mention}\n\n{message.content}")
                            return

        except Exception as exc:
            print(traceback.format_exc())



    class SelectD(discord.ui.Select):
        def __init__(self):
            options = [
                discord.SelectOption(label="Economy commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Invites commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Fun commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Giveaways commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Moderation commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Admin commands", description="Shows all the economy commands"),
                discord.SelectOption(label="Giveaways commands", description="Shows all the economy commands")
            ]
            super().__init__(placeholder="Which help section do you want ?", min_values=1, max_values=1, options=options)
        
        async def callback(self, interaction: discord.Interaction):
            await interaction.response.send_message("You selected: " + self.values[0], ephemeral=True)

    
    @app_commands.command(name="say", description="Say something as the bot")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def say(self, interaction: discord.Interaction, channel: discord.TextChannel, *, title: str = None, message: str = None, img: discord.Attachment = None):
             title_text = f"<a:green_crown_fuzz:1105696623155228753>{title}<a:green_crown_fuzz:1105696623155228753>" if title else ''
             message_text = f" {message} " if message else None

             embed = discord.Embed(title=title_text, description=message_text, colour=self.client.colour)

             if img:
                 embed.set_image(url=img.url)

             await channel.send(embed=embed)
             await interaction.response.send_message("Sent!", ephemeral=True)

    
    dico = {}
    
    @app_commands.command(name="addbutton", description="Add a button to a message")
    async def addbutton(self, interaction: discord.Interaction, messageid: str, content: str, emoji: str, role: discord.Role):
        try:
            conn = sqlite3.connect('Data/user.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO roles (channelid, messageid, roleid, emoji, content) VALUES (?, ?, ?, ?, ?)', (interaction.channel.id,messageid, role.id, emoji, content))
            conn.commit()
            conn.close()
            messageid = int(messageid)
            message = await interaction.channel.fetch_message(messageid)
            view = mAddBtn(content, emoji, role)
        
            # Get the existing buttons on the message and add the new one
            if message.components:
                for i in message.components[0].children:
                    btn2 = Button(label=i.label, style=i.style, emoji=i.emoji, custom_id=i.custom_id)
                    conn = sqlite3.connect('Data/user.db')
                    cursor = conn.cursor()
                    roleid_sql = cursor.execute('SELECT roleid FROM roles WHERE messageid = ? AND content = ?', (messageid,i.label)).fetchone()
                    role = interaction.guild.get_role(roleid_sql[0])
                    async def callbackt(interaction):
                        if role in interaction.user.roles:
                            await interaction.user.remove_roles(discord.Object(id=roleid_sql[0]))
                            await interaction.response.send_message("Role removed!", ephemeral=True)
                        else:
                            await interaction.user.add_roles(discord.Object(id=roleid_sql[0]))
                            await interaction.response.send_message("Role added!", ephemeral=True)
                    btn2.callback = callbackt
                    conn.close()
                    view.add_item(btn2)
            conn = sqlite3.connect('Data/user.db')
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM roles')
            print(cursor.fetchall())
            conn.close()

            await message.edit(view=view)
            await interaction.response.send_message("Button added!", ephemeral=True)
        except Exception as e:
            print(e)


    @app_commands.command(name="removebuttons", description="Remove buttons from a message")
    async def removebuttons(self, interaction: discord.Interaction, messageid: str, content: str):
        messageid = int(messageid)
        message = await interaction.channel.fetch_message(messageid)
        new_view = View()
        for i in message.components[0].children:
            conn = sqlite3.connect('Data/user.db')
            cursor = conn.cursor()
            roleid_sql = cursor.execute('SELECT roleid FROM roles WHERE messageid = ? AND content = ?', (messageid,i.label)).fetchone()
            conn.close()
            role = interaction.guild.get_role(roleid_sql[0])
            
            if i.label != content:
                btn = Button(label=i.label, style=i.style, emoji=i.emoji, custom_id=i.custom_id)
                async def callbackt(interaction):
                    if role in interaction.user.roles:
                        await interaction.user.remove_roles(discord.Object(id=roleid_sql[0]))
                        await interaction.response.send_message("Role removed!", ephemeral=True)
                    else:
                        await interaction.user.add_roles(discord.Object(id=roleid_sql[0]))
                        await interaction.response.send_message("Role added!", ephemeral=True)
                btn.callback = callbackt
                new_view.add_item(btn)
                
        conn = sqlite3.connect('Data/user.db')
        cursor = conn.cursor()
        cursor.execute('DELETE FROM roles WHERE messageid = ? AND content = ?', (messageid,content))
        conn.commit()
        conn.close()
        await message.edit(view=new_view)
        await interaction.response.send_message("Buttons removed!", ephemeral=True)
            
    @app_commands.command(name="help", description="Displays all commands")
    async def help(self, interaction: discord.Interaction):
        select = Select(
            placeholder="Which help section do you want ?",
            options=[
                SelectOption(label="📈 Economy commands", description="Shows all the economy commands", value="1"),
                SelectOption(label="📢 Invites commands", description="Shows all the economy commands", value="2"),
                SelectOption(label="🎉 Fun commands", description="Shows all the economy commands", value="3"),
                SelectOption(label="🎁 Giveaways commands", description="Shows all the economy commands", value="4"),
                SelectOption(label="🔨 Moderation commands", description="Shows all the economy commands", value="5"),
                SelectOption(label="🔒 Admin commands", description="Shows all the economy commands", value="6"),
            ])
        async def callback(interaction):
            if select.values[0] == "1":
                await interaction.response.edit_message(embed=eco_embed, view=None)
            elif select.values[0] == "2":
                await interaction.response.edit_message(embed=invite_embed, view=None)
            elif select.values[0] == "3":
                await interaction.response.edit_message(embed=fun_embed, view=None)
            elif select.values[0] == "4":
                await interaction.response.edit_message(embed=give_embed, view=None)
            elif select.values[0] == "5":
                await interaction.response.edit_message(embed=mod_embed, view=None)
            elif select.values[0] == "6":
                await interaction.response.edit_message(embed=admin_embed, view=None)
                
        select.callback = callback
        
        embed = discord.Embed(title="Help", colour=self.client.colour, description="Select a category to see the commands")
        
        eco_embed = discord.Embed(title="Economy", colour=self.client.colour, description="Here are all the economy commands").add_field(name="Balance", value="`/balance`", inline=False).add_field(name="Leaderboard", value="`/leaderboard`", inline=False).add_field(name="Daily", value="`/daily`", inline=False).add_field(name="Work", value="`/work`", inline=False).add_field(name="Rob", value="`/rob`", inline=False).add_field(name="Bet", value="`/bet`", inline=False).add_field(name="Crash", value="`/crash`", inline=False).add_field(name="Dice", value="`/dice`", inline=False).add_field(name="Send", value="`/send`", inline=False).add_field(name="Addmoney", value="`/addmoney`", inline=False).add_field(name="Removemoney", value="`/removemoney`", inline=False)
        invite_embed = discord.Embed(title="Invites", colour=self.client.colour, description="Here are all the invites commands").add_field(name="Invites", value="`/invites`", inline=False)
        fun_embed = discord.Embed(title="Fun", colour=self.client.colour, description="Here are all the fun commands").add_field(name="Coinflip", value="`/coinflip`", inline=False).add_field(name="RPS", value="`/rps`", inline=False).add_field(name="Play", value="`/play`", inline=False).add_field(name="Stop", value="`/stop`", inline=False).add_field(name="Join", value="`/join`", inline=False)
        give_embed = discord.Embed(title="Giveaways", colour=self.client.colour, description="Here are all the giveaways commands").add_field(name="Giveaway", value="`/giveaway`", inline=False).add_field(name="End", value="`/end`", inline=False).add_field(name="Reroll", value="`/reroll`", inline=False)
        mod_embed = discord.Embed(title="Moderation", colour=self.client.colour, description="Here are all the moderation commands").add_field(name="Ban", value="`/ban`", inline=False).add_field(name="Kick", value="`/kick`", inline=False).add_field(name="Unban", value="`/unban`", inline=False).add_field(name="Mute", value="`/mute`", inline=False).add_field(name="Unmute", value="`/unmute`", inline=False).add_field(name="Nuke", value="`/nuke`", inline=False).add_field(name="Purge", value="`/purge`", inline=False).add_field(name="Lock", value="`/lock`", inline=False).add_field(name="Unlock", value="`/unlock`", inline=False).add_field(name="Warn", value="`/warn`", inline=False).add_field(name="Warnings", value="`/warnings`", inline=False).add_field(name="Sticky", value="`/sticky`", inline=False).add_field(name="Unsticky", value="`/unsticky`", inline=False)
        admin_embed = discord.Embed(title="Admin", colour=self.client.colour, description="Here are all the admin commands").add_field(name="Steal", value="`/steal`", inline=False).add_field(name="Ticketpanel", value="`/ticketpanel`", inline=False).add_field(name="Verifypanel", value="`/verifypanel`", inline=False).add_field(name="Reactionroles", value="`/reactionroles`", inline=False).add_field(name="Voicepanel", value="`/voicepanel`", inline=False).add_field(name="Stats", value="`/stats`", inline=False)
        
        async def callback_1(interaction):
            await interaction.response.edit_message(embed=eco_embed, view=view1)
        async def callback_2(interaction):
            await interaction.response.edit_message(embed=embed, view=view)
        async def callback_3(interaction):
            await interaction.response.edit_message(embed=invite_embed, view=view2)
        async def callback_4(interaction):
            await interaction.response.edit_message(embed=eco_embed, view=view1)
        async def callback_5(interaction):
            await interaction.response.edit_message(embed=fun_embed, view=view3)
        async def callback_6(interaction):
            await interaction.response.edit_message(embed=invite_embed, view=view2)
        async def callback_7(interaction):
            await interaction.response.edit_message(embed=give_embed, view=view4)
        async def callback_8(interaction):
            await interaction.response.edit_message(embed=fun_embed, view=view3)
        async def callback_9(interaction):
            await interaction.response.edit_message(embed=mod_embed, view=view5)
        async def callback_10(interaction):
            await interaction.response.edit_message(embed=give_embed, view=view4)
        async def callback_11(interaction):
            await interaction.response.edit_message(embed=admin_embed, view=view6)
        async def callback_12(interaction):
            await interaction.response.edit_message(embed=mod_embed, view=view5)
        
        
        view = View()
        next = Button(label="Next", style=discord.ButtonStyle.green)
        view.add_item(next)
        next.callback = callback_1

        view1 = View()
        previous_1 = Button(label="Previous", style=discord.ButtonStyle.green)
        view1.add_item(previous_1)
        previous_1.callback = callback_2
        next_1 = Button(label="Next", style=discord.ButtonStyle.green)
        view1.add_item(next_1)
        next_1.callback = callback_3
        
        view2 = View()
        previous_2 = Button(label="Previous", style=discord.ButtonStyle.green)
        view2.add_item(previous_2)
        previous_2.callback = callback_4
        next_2 = Button(label="Next", style=discord.ButtonStyle.green)
        view2.add_item(next_2)
        next_2.callback = callback_5
        
        view3 = View()
        previous_3 = Button(label="Previous", style=discord.ButtonStyle.green)
        view3.add_item(previous_3)
        previous_3.callback = callback_6
        next_3 = Button(label="Next", style=discord.ButtonStyle.green)
        view3.add_item(next_3)
        next_3.callback = callback_7
        
        view4 = View()
        previous_4 = Button(label="Previous", style=discord.ButtonStyle.green)
        view4.add_item(previous_4)
        previous_4.callback = callback_8
        next_4 = Button(label="Next", style=discord.ButtonStyle.green)
        view4.add_item(next_4)
        next_4.callback = callback_9
        
        view5 = View()
        previous_5 = Button(label="Previous", style=discord.ButtonStyle.green)
        view5.add_item(previous_5)
        previous_5.callback = callback_10
        next_5 = Button(label="Next", style=discord.ButtonStyle.green)
        view5.add_item(next_5)
        next_5.callback = callback_11
        
        view6 = View()
        previous_6 = Button(label="Previous", style=discord.ButtonStyle.green)
        view6.add_item(previous_6)
        previous_6.callback = callback_12

        select_view = View()
        select_view.add_item(select)
        
        
        
        
        

        await interaction.response.send_message(embed=embed, view=select_view)
        return
    

    @app_commands.command(name="unsticky", description="Remove a stickied message (Admin)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def unsticky(self, interaction: discord.Interaction):
        if interaction.channel.id not in self.client.sticky:
            await interaction.response.send_message(f"🗂️ There is no stickied message here.")
            return
        else:
            conn = sqlite3.connect('sticky.db')
            cursor = conn.cursor()
            cursor.execute('SELECT * from infos_salons')
            rows = cursor.fetchall()
            print(rows)
            cursor.execute('SELECT * FROM infos_salons WHERE id_salon = ?', (interaction.channel.id,))
            existing_entry = cursor.fetchone()
            if existing_entry[1] != "":
            # Mettre à jour l'entrée existante
                cursor.execute('UPDATE infos_salons SET contenu = "" WHERE id_salon = ?', (interaction.channel.id,))
            cursor.execute('SELECT * from infos_salons')
            rows = cursor.fetchall()
            print(rows)
            conn.commit()
            conn.close()
            del self.client.sticky[interaction.channel.id]
            await interaction.response.send_message(f"🗂️ Unstickied the message.")
            return


    @app_commands.command(name="sticky", description="Sticky a message (Admin)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def sticky(self, interaction: discord.Interaction, member: discord.Member = None):
        member = interaction.user if member is None else member
        async for msg in interaction.channel.history(limit=None, oldest_first=False):
            if msg.author == member:
                lastmsg = msg
                break
        
        
        
        if not lastmsg:
            await interaction.response.send_message("No message to stick.", ephemeral=True)
            return
        
        conn = sqlite3.connect('sticky.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM infos_salons WHERE id_salon = ?', (interaction.channel.id,))
        existing_entry = cursor.fetchone()
        if existing_entry:
        # Mettre à jour l'entrée existante
            cursor.execute('UPDATE infos_salons SET contenu = ? WHERE id_salon = ?', (lastmsg.content, interaction.channel.id))
        else:
            # Ajouter une nouvelle entrée
            cursor.execute('INSERT INTO infos_salons (id_salon, contenu) VALUES (?, ?)', (interaction.channel.id, lastmsg.content))
        conn.commit()
        conn.close()
        
        
        @tasks.loop(seconds=12)
        async def stickyloop(channel: discord.TextChannel, message: str):
            print(message)
            if channel.id not in self.client.sticky:
                stickyloop.stop()
                return
            
            elif self.client.sticky[channel.id] != message:
                stickyloop.stop()
                return
            
            msgz = []
            async for msg in channel.history(limit=20, oldest_first=False):
                msgz.append(msg.content)
            
            if message not in msgz:
                await channel.send(f"{message}")

        
        self.client.sticky[interaction.channel.id] = lastmsg.content
        stickyloop.start(interaction.channel, lastmsg.content)
        conn = sqlite3.connect('sticky.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM infos_salons")
        rows = cursor.fetchall()
        print(rows)
        conn.close()
        
        await interaction.response.send_message(f"🗂️ Stickied.")
        return

        
        

    

    @app_commands.command(name="coinflip", description="Play coinflip with the bot")
    #@app_commands.choices(choice=[
        #app_commands.Choice(name="Heads", value="Heads"),
       # app_commands.Choice(name="Tails", value="Tails"),
    #])
    async def coinflip(self, interaction: discord.Interaction):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        choices = ["heads", "tails"]
        choice = random.choice(choices)

        emb = discord.Embed(colour=discord.Colour.blue())
        emb.set_author(name=f"{choice.capitalize()}!", icon_url=userpfp)
        if choice == "heads":
            emb.set_image(url="https://i.ibb.co/rHtXXz0/heads-coinflip-1.gif")
        else:
            emb.set_image(url="https://i.ibb.co/DkvgBCt/coins-tails.gif")
        await interaction.response.send_message(embed=emb)
        return
    


    @app_commands.command(name="rps", description="Play rock/paper/scissors with the bot")
    @app_commands.choices(choice=[
        app_commands.Choice(name="Rock", value="Rock"),
        app_commands.Choice(name="Paper", value="Paper"),
        app_commands.Choice(name="Scissors", value="Scissors")
    ])
    async def rps(self, interaction: discord.Interaction, choice: app_commands.Choice[str]):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        # AUTHOR URL?

        choices = ["rock", "paper", "scissors"]
        choice = choice.value.lower()
        botchoice = random.choice(choices)
        yourem = choice.replace("rock", "🪨").replace("paper", "📜").replace("scissors", "✂️")
        botem = botchoice.replace("rock", "🪨").replace("paper", "📜").replace("scissors", "✂️")
        if choice == botchoice:
            emb = discord.Embed(title="Draw!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=discord.Colour.grey())
            #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
            await interaction.response.send_message(embed=emb)
            return
        elif choice == "rock":
            if botchoice == "paper":
                emb = discord.Embed(title="You lost!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=discord.Colour.red())
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return
            elif botchoice == "scissors":
                emb = discord.Embed(title="You win!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=self.client.colour)
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return
        elif choice == "paper":
            if botchoice == "scissors":
                emb = discord.Embed(title="You lost!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=discord.Colour.red())
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return
            elif botchoice == "rock":
                emb = discord.Embed(title="You win!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=self.client.colour)
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return
        elif choice == "scissors":
            if botchoice == "rock":
                emb = discord.Embed(title="You lost!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=discord.Colour.red())
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return
            elif botchoice == "paper":
                emb = discord.Embed(title="You win!", description=f"{interaction.user.mention} {yourem}\n{self.client.user.mention} {botem}", colour=self.client.colour)
                #emb.set_image(url="https://giphy.com/embed/3oEjHVNeiP3utYQyoE")
                await interaction.response.send_message(embed=emb)
                return

        
    
class mAddBtn(View):
    def __init__(self, content: str=None, emoji: str=None, role: discord.Role=None):
        try:
            super().__init__(timeout=None)
            b = Button(label=content, style=discord.ButtonStyle.green, custom_id=content, emoji=emoji)
            async def callbackt(interaction):
                try:
                    print(role)
                    r = interaction.guild.get_role(role.id)
                    if r in interaction.user.roles:
                        await interaction.user.remove_roles(role)
                        await interaction.response.send_message("Role removed!", ephemeral=True)
                    else:
                        await interaction.user.add_roles(role)
                        await interaction.response.send_message("Role added!", ephemeral=True)
                    print(role, interaction.user.roles)
                except Exception as e:
                    print(e)
            b.callback = callbackt
            self.add_item(b)
        except Exception as e:
            print(e)


        





async def setup(client):
    await client.add_cog(MembersCommand(client))