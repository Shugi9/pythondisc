import json
import discord
from discord import app_commands
from discord.ext import commands
import time
import os
import asyncio
import datetime
import sqlite3
import traceback



class ModsCommand(commands.Cog):
    def __init__(self, client):
        self.client = client


    def connect(self):
        try:
            conn = sqlite3.connect(f"Data/users.db")
            curs = conn.cursor()
            return conn, curs
        except Exception as exc:
            print(exc)
            return None


    @app_commands.command(name="steal", description="Steal an emoji")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def steal(self, interaction: discord.Interaction):
        
        await interaction.response.send_message(f"{interaction.user.mention} React to this message with an emoji to steal") #, ephemeral=True, delete_after=0.5)
        return
    

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        try:
            channel: discord.TextChannel = self.client.get_channel(payload.channel_id)
            msg: discord.Message = await channel.fetch_message(payload.message_id)
            if msg.author.id == self.client.user.id:
                if msg.content.startswith(payload.member.mention):
                    emoji = payload.emoji
                    em = await channel.guild.create_custom_emoji(name=emoji.name, image=await emoji.read())
                    await msg.edit(content=f"Stole emoji {str(em)}")
        except Exception:
            print(traceback.format_exc())
    


        
        


        


    @steal.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)


    @app_commands.command(name="warnings", description="See all warnings of a member (Admin)")
    @app_commands.checks.has_permissions(administrator=True)
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        result = self.connect()
        if result is None:
            return
        
        if member.avatar is None:
            userpfp = member.default_avatar
        else:
            userpfp = member.avatar

        userid = member.id

        conn, curs = result

        query = f"""SELECT reason, warner FROM warnings WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()
        conn.close()
        
        if len(records) == 0:
            emb = discord.Embed(title=f"Warnings (0)", colour=discord.Colour.green())
            emb.set_author(name=member, icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        
        warntext = ""
        for index, record in enumerate(records):
            reason, warner = record
            warntext = warntext + f"**{index+1}.** {reason} - <@{warner}>\n"



        class ChoiceView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)

            @discord.ui.button(emoji="🗑️", label="Clear", custom_id=f"clear_{userid}", disabled=False)
            async def clearwarnings(self, inter: discord.Interaction, button: discord.Button):
                if interaction.user.id != inter.user.id:
                    return

                button.disabled = True
                class NewView(discord.ui.View):
                    def __init__(self):
                        super().__init__(timeout=None)
                        self.add_item(button)


                conn = sqlite3.connect(f"Data/users.db")
                curs = conn.cursor()
                query = f"""DELETE FROM warnings WHERE userid={userid}"""
                curs.execute(query)
                conn.commit()
                conn.close()
                emb = inter.message.embeds[0]
                emb.title = "Warnings (0)"
                emb.description = ""
                emb.colour = discord.Colour.green()
                await inter.response.edit_message(embed=emb, view=NewView())
                return

        
        emb = discord.Embed(title=f"Warnings ({len(records)})", description=warntext, colour=discord.Colour.red())
        emb.set_author(name=member, icon_url=userpfp)
        await interaction.response.send_message(embed=emb, view=ChoiceView())
        return
    

    @warnings.error 
    async def catch(self, interaction, error):
        print(error)
       
    @app_commands.command(name="warn", description="Warn a member (Admin)")
    @app_commands.checks.has_permissions(administrator=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: app_commands.Range[str, 1, 250] = None):
        result = self.connect()
        if result is None:
            return

        if member.avatar is None:
            userpfp = member.default_avatar
        else:
            userpfp = member.avatar

        userid = member.id
        conn, curs = result

        oldreason = reason
        if reason is None:
            reason = ""
        reason = reason.replace("'", "''")
        

        query = f"""INSERT INTO warnings(userid, reason, warner) VALUES({userid}, '{reason}', {interaction.user.id})"""
        curs.execute(query)
        conn.commit()
        conn.close()


        class ChoiceView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)

            @discord.ui.button(emoji="🗑️", label="Undo", custom_id=f"undo_{userid}")
            async def undowarning(self, inter: discord.Interaction, button: discord.Button):
                if interaction.user.id != inter.user.id:
                    return
                
                try:

                    conn = sqlite3.connect(f"Data/users.db")
                    curs = conn.cursor()

                    query = f"""SELECT reason, warner FROM warnings WHERE userid={userid}"""
                    curs.execute(query)
                    records = curs.fetchall()

                    if len(records) == 0:
                        await inter.message.delete()
                        return
                    
                    query = f"""DELETE FROM warnings WHERE userid={userid} AND reason='{reason}' AND warner={interaction.user.id}"""
                    curs.execute(query)
                    conn.commit()
                    conn.close()
                    await inter.message.delete()
                    return
                except Exception as exc:
                    print(exc)
        
        emb = discord.Embed(colour=discord.Colour.red(), timestamp=datetime.datetime.now())
        emb.set_author(name=f"Member Warned", icon_url=userpfp)
        emb.add_field(name="Who", value=member.mention, inline=False)
        emb.add_field(name="By", value=interaction.user.mention, inline=False)
        emb.add_field(name="Reason", value=reason, inline=False)
        await interaction.response.send_message(embed=emb, view=ChoiceView())

        try:
            emb = discord.Embed(description=f"You have been warned in **{interaction.guild.name}**", colour=discord.Colour.red())
            emb.set_author(name=member, icon_url=userpfp)
            emb.add_field(name="Reason", value=reason, inline=False)
            await member.send(embed=emb)
        except:
            pass

        return
    

    @warn.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)

        
    @app_commands.command(name="stats", description="Displays server stats")
    async def stats(self, interaction: discord.Interaction):
        await interaction.response.defer()
        online = 0
        offline = 0
        bots = 0
        for member in interaction.guild.members:
            if member.bot:
                bots += 1
            elif str(member.status) == "offline":
                offline += 1
            else:
                online += 1

        boosts = interaction.guild.premium_subscription_count
        owner = interaction.guild.owner.mention
        timer = int(str(interaction.guild.created_at.timestamp()).split(".")[0])

        emb = discord.Embed(title=interaction.guild.name, colour=self.client.colour, timestamp=datetime.datetime.now())
        emb.add_field(name="Online", value=online, inline=True)
        emb.add_field(name="Offline", value=offline, inline=True)
        emb.add_field(name="Bots", value=bots, inline=True)
        emb.add_field(name="Boosts", value=boosts, inline=True)
        emb.add_field(name="Created At", value=f"<t:{timer}>", inline=False)
        emb.add_field(name="Owner", value=owner, inline=False)
        await interaction.followup.send(embed=emb)
        return


    @stats.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)
        
    

    @app_commands.command(name="lock", description="Lock a channel")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def lock(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Locked {interaction.channel.mention}")
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = False
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        return
    


    @app_commands.command(name="unlock", description="Unlock a channel")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def unlock(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Unlocked {interaction.channel.mention}")
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = True
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        return
    

    @app_commands.command(name="purge", description="Purge messages")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100000]):
        await interaction.response.send_message(f"Purging **{amount}** messages")
        await interaction.channel.purge(limit=amount+1)
        return



    @app_commands.command(name="nuke", description="Nuke")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def nuke(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Nuking this channel...")
        chanpos = interaction.channel.position
        newchan = await interaction.channel.clone()
        await interaction.channel.delete()
        await newchan.edit(position=chanpos, sync_permissions=True)
        await newchan.send(f"Channel nuked by {interaction.user.mention}", delete_after=5)
        return
    


    @app_commands.command(name="timeout", description="Timeout a member")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, minutes: int):
        then = datetime.datetime.now(tz=datetime.timezone.utc) + datetime.timedelta(minutes=minutes)
        
        await member.timeout(then)
        await interaction.response.send_message(f"{member.mention} has been timed out for **{minutes}** minutes.")
        return
    

    @app_commands.command(name="untimeout", description="Remove a timeout of a member")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member):
        then = datetime.datetime.now(tz=datetime.timezone.utc) - datetime.timedelta(minutes=1)
        await member.timeout(then)
        await interaction.response.send_message(f"{member.mention} is not timed out anymore.")
        return

    

    @app_commands.command(name="unmute", description="Unmute a member")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        if member.id == interaction.user.id:
            await interaction.response.send_message("You can't unmute yourself", ephemeral=True)
            return
        
        try:
            role = discord.utils.get(interaction.guild.roles, name='muted')
            if role is None:
                perms = discord.Permissions(send_messages=False)
                role = await interaction.guild.create_role(name="muted", permissions=perms)
            if role in member.roles:
                await member.remove_roles(role)
        except Exception as exc:
            await interaction.response.send_message(f"Could not unmute {member.mention}", ephemeral=True)
            return
        
        await interaction.response.send_message(f"{member.mention} has been unmuted.")
        return
    


    @app_commands.command(name="mute", description="Mute a member")
    @app_commands.checks.has_permissions(ban_members=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member):
        if member.id == interaction.user.id:
            await interaction.response.send_message("You can't mute yourself", ephemeral=True)
            return
        
        try:
            role = discord.utils.get(interaction.guild.roles, name='muted')
            if role is None:
                perms = discord.Permissions(send_messages=False)
                role = await interaction.guild.create_role(name="muted", permissions=perms)
            await member.add_roles(role)

            for channel in interaction.guild.text_channels:
                try:
                    await channel.set_permissions(role, send_messages=False)
                except Exception as exc:
                    print(exc)
                    continue
        except Exception as exc:
            await interaction.response.send_message(f"Could not mute {member.mention}", ephemeral=True)
            return
        
        await interaction.response.send_message(f"{member.mention} has been muted.")
        return
    
    @mute.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)


    @app_commands.command(name="ban", description="Ban a member")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = None):
        if member.id == interaction.user.id:
            await interaction.response.send_message("You can't ban yourself", ephemeral=True)
            return
        await interaction.guild.ban(member, reason=reason)
        await interaction.response.send_message(f"{member.mention} has been banned.")
        return
    

    @app_commands.command(name="unban", description="Unban a member")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, member: discord.User):
        if member.id == interaction.user.id:
            await interaction.response.send_message("You can't unban yourself", ephemeral=True)
            return

        await interaction.guild.unban(member)
        await interaction.response.send_message(f"{member.mention} has been unbanned.")
        return
    
    @unban.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)


    @app_commands.command(name="kick", description="Kick a member")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = None):
        if member.id == interaction.user.id:
            await interaction.response.send_message("You can't kick yourself", ephemeral=True)
            return
        await interaction.guild.kick(member, reason=reason)
        await interaction.response.send_message(f"{member.mention} has been kicked.")
        return

    
    @untimeout.error 
    async def catch(self, interaction, error):
        await interaction.response.send_message(f"Error, I probably don't have permissions to do that.")
        return
        
    @timeout.error 
    async def catch(self, interaction, error):
        await interaction.response.send_message(f"Error, I probably don't have permissions to do that.")
        return
    
    @unban.error 
    async def catch(self, interaction, error):
        await interaction.response.send_message(f"Error, I probably don't have permissions to do that.")
        return
    
    @ban.error 
    async def catch(self, interaction, error):
        await interaction.response.send_message(f"Error, I probably don't have permissions to do that.")
        return


    @kick.error 
    async def catch(self, interaction, error):
        await interaction.response.send_message(f"Error, I probably don't have permissions to do that.")
        return



async def setup(client):
    await client.add_cog(ModsCommand(client))