import time
import discord
from discord import app_commands
from discord.ext import commands
import json
# import youtube_dl
import yt_dlp
import asyncio
import sys


class Start(commands.Cog):
    def __init__(self, client):
        self.client = client


    @app_commands.command(name="join", description="Make bot join your VC")
    async def join(self, interaction: discord.Interaction):
        member = interaction.guild.get_member(interaction.user.id)
        if member.voice is None:
            await interaction.response.send_message(f"You are not in a VC in this server!", ephemeral=True)
            return
        channel = member.voice.channel
        if member.voice.channel is None:
            await interaction.response.send_message(f"You are not in a VC in this server!", ephemeral=True)
            return
        voice = discord.utils.get(self.client.voice_clients, guild=interaction.guild)
        if voice and voice.is_connected():
            await voice.move_to(channel)
        else:
            await channel.connect()

        await interaction.response.send_message(f"Bot joined **{member.voice.channel.name}** - Use /play to play a youtube video.")
        return

    @app_commands.command(name="stop", description="Stop playing music.")
    async def stop(self, interaction: discord.Interaction):
        voice = discord.utils.get(self.client.voice_clients, guild=interaction.guild)
        if voice is None:
            await interaction.response.send_message(f"Bot is not playing.", ephemeral=True)
            return
        elif voice.is_connected():
            await voice.disconnect()
            await interaction.response.send_message(f"Music playing stopped.")
            return
        else:
            await interaction.response.send_message(f"Bot is not playing.", ephemeral=True)
            return


    @app_commands.command(name="play", description="Play a youtube video")
    async def play(self, interaction: discord.Interaction, url: app_commands.Range[str, 1, 1000]):
        ffmpeg_options = {'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                          'options': '-vn'}
        ydl_opts = {'format': 'bestaudio'}

        member = interaction.guild.get_member(interaction.user.id)
        if member.voice is None:
            await interaction.response.send_message(f"You are not in a VC in this server!", ephemeral=True)
            return
        if member.voice.channel is None:
            await interaction.response.send_message(f"You are not in a VC in this server!", ephemeral=True)
            return

        channel = member.voice.channel

        if "youtube" not in url:
            if "youtu.be" not in url:
                await interaction.response.send_message(f"URL not supported", ephemeral=True)
                return
            
        if "watch" not in url:
            await interaction.response.send_message(f"URL not supported", ephemeral=True)
            return
        

        await interaction.response.send_message(f"Started playing {url} in **{member.voice.channel.name}**")

        voice = discord.utils.get(self.client.voice_clients, guild=interaction.guild)
        if voice and voice.is_connected():
            await voice.move_to(channel)
        else:
            voice = await channel.connect()



        try:
            if voice.is_connected() is False:
                return

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                song_info = ydl.extract_info(url, download=False)

            fullp = str(sys.path[0]) + "\\" + "ffmpeg.exe"
            voice.play(discord.FFmpegPCMAudio(song_info["url"], **ffmpeg_options,
                                                executable=fullp))
            voice.is_playing()
        except discord.ClientException:
            return

        return


    @stop.error
    async def catch_error(self, interaction, error):
        print(error)


    @join.error
    async def catch_error(self, interaction, error):
        print(error)


    @play.error
    async def catch_error(self, interaction, error):
        print(error)

        emb = discord.Embed(title="Unkown Error", description=f"``{error}``", colour=discord.Colour.red())
        emb.set_footer(text="Contact Developer", icon_url=None)
        try:
            await interaction.response.send_message(embed=emb)
        except Exception as exc:
            await interaction.channel.send(embed=emb)
            return










async def setup(client):
    await client.add_cog(Start(client))
