import json
import discord
from discord import app_commands
from discord.ext import commands
import time
import os
import asyncio
import requests
import datetime
import random, string
import sqlite3



class GiveawayCommands(commands.Cog):
    def __init__(self, client):
        self.client = client
        

    def connect(self):
        try:
            conn = sqlite3.connect(f"Data/users.db")
            curs = conn.cursor()
            return conn, curs
        except Exception as exc:
            print(exc)
            return None
        

    @app_commands.command(name="reroll", description="Reroll a giveaway")
    @app_commands.checks.has_permissions(administrator=True)
    async def reroll(self, interaction: discord.Interaction, giveawayid: int):
        await interaction.response.defer()
        result = GiveawayCommands.connect(self)
        if result is None:
            return

        conn = result[0]
        curs = result[1]
        query = f"""SELECT message FROM giveaways WHERE id={giveawayid} AND channel={interaction.channel.id}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            await interaction.followup.send(f"No giveaway found.")
            return
        
        messageid = records[0][0]
        message = await interaction.channel.fetch_message(messageid)
        if message is None:
            await interaction.followup.send(f"No giveaway found.")
            return
        
        query = f"""UPDATE giveaways SET (ended) = (1) WHERE id={giveawayid}"""
        curs.execute(query)
        conn.commit()
        conn.close()
        
        prize = message.embeds[0].title
        winners = int(message.embeds[0].description.split("Winners:** ")[1].split("**Ends")[0].replace("\n", "").replace(r"\n", ""))
        
        choices = []
        for r in message.reactions:
            if r.emoji == "🎉":
                async for user in r.users():
                    if user.id == self.client.user.id:
                        continue
                    choices.append(user)
                break
        
        if len(choices) < winners:
            await interaction.followup.send(f"Not enough participants for this giveaway.")
            return
        
        winnerlist = random.choices(choices, k=winners)
        print(winnerlist)
        winnerz = []
        for winner in winnerlist:
            winnerz.append(winner.mention)

        winnerz = str(winnerz).replace("[", "").replace("]", "").replace("'", "")

        emb = discord.Embed(title=prize, colour=self.client.colour)
        emb.add_field(name="Winners", value=winnerz, inline=False)
        emb.set_footer(text="Giveaway rerolled")
        await interaction.followup.send(embed=emb)
        return
        

    @app_commands.command(name="end", description="End a giveaway")
    @app_commands.checks.has_permissions(administrator=True)
    async def end(self, interaction: discord.Interaction, giveawayid: int):
        await interaction.response.defer()
        result = GiveawayCommands.connect(self)
        if result is None:
            return

        conn = result[0]
        curs = result[1]
        query = f"""SELECT message FROM giveaways WHERE id={giveawayid} AND channel={interaction.channel.id}"""
        curs.execute(query)
        records = curs.fetchall()
        if len(records) == 0:
            await interaction.followup.send(f"No giveaway found.")
            return
        
        messageid = records[0][0]
        message = await interaction.channel.fetch_message(messageid)
        if message is None:
            await interaction.followup.send(f"No giveaway found.")
            return
        
        if "Giveaway ended" in message.embeds[0].description:
            await interaction.followup.send(f"Giveaway has already ended.")
            return
        
        query = f"""UPDATE giveaways SET (ended) = (1) WHERE id={giveawayid}"""
        curs.execute(query)
        conn.commit()
        conn.close()
        
        prize = message.embeds[0].title
        winners = int(message.embeds[0].description.split("Winners:** ")[1].split("**Ends")[0].replace("\n", "").replace(r"\n", ""))
        
        choices = []
        for r in message.reactions:
            if r.emoji == "🎉":
                async for user in r.users():
                    if user.id == self.client.user.id:
                        continue
                    choices.append(user)

                break
        
        if len(choices) < winners:
            await interaction.followup.send(f"Not enough participants for this giveaway.")
            return
        
        winnerlist = random.choices(choices, k=winners)
        print(winnerlist)
        winnerz = []
        for winner in winnerlist:
            winnerz.append(winner.mention)

        winnerz = str(winnerz).replace("[", "").replace("]", "").replace("'", "")

        ember = message.embeds[0]
        ember.description = f'{message.embeds[0].description.split("React with")[0]}Giveaway ended.'
        await message.edit(embed=ember)


        emb = discord.Embed(title=prize, colour=self.client.colour)
        emb.add_field(name="Winners", value=winnerz, inline=False)
        emb.set_footer(text="Giveaway ended")
        await interaction.followup.send(embed=emb)
        return


    @app_commands.command(name="giveaway", description="Start a giveaway")
    @app_commands.checks.has_permissions(administrator=True)
    async def giveaway(self, interaction: discord.Interaction, prize: app_commands.Range[str, 1, 150], winners: app_commands.Range[int, 1, 100], minutes: int = None, hours: int = None, days: int = None):
        total = 0
        if minutes is not None:
            total += minutes
        elif hours is not None:
            total += (hours * 60)
        elif days is not None:
            total += (days * 1440)

        if total == 0:
            await interaction.response.send_message("Please give a duration.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        result = GiveawayCommands.connect(self)
        if result is None:
            return

        conn = result[0]
        curs = result[1]
        
        while True:
            giveawayid = "".join(random.choices(string.digits, k=4))
            query = f"""SELECT * FROM giveaways WHERE id={giveawayid}"""
            curs.execute(query)
            records = curs.fetchall()
            if len(records) == 0:
                break

        timepart = int(str((datetime.datetime.now() + datetime.timedelta(minutes=total)).timestamp()).split(".")[0])
        await interaction.followup.send(f"Giveaway created. ID: {giveawayid}", ephemeral=True)
        emb = discord.Embed(title=prize, description=f"**Started by:** {interaction.user.mention}\n**Winners:** {winners}\n**Ends at:** <t:{timepart}>\n\nReact with 🎉 to enter.", colour=self.client.colour)
        emb.set_footer(text=f"ID: {giveawayid}", icon_url=None)
        msg = await interaction.channel.send(embed=emb)
        await msg.add_reaction("🎉")

        prize = prize.replace("'", "''")
        query = f"""INSERT INTO giveaways(id, ends, channel, message, ended) VALUES({giveawayid}, {timepart}, {interaction.channel.id}, {msg.id}, 0)"""
        curs.execute(query)
        conn.commit()
        conn.close()
        return
    





    @giveaway.error 
    async def catch(self, interaction, error):
        print(error)

    @end.error 
    async def catch(self, interaction, error):
        print(error)




async def setup(client):
    await client.add_cog(GiveawayCommands(client))