import json
import discord
from discord import app_commands
from discord.ext import commands
import time
import os
import asyncio
import sqlite3
import datetime

from colorama import init, Fore, Style
print(" ")
# Initialize colorama
init()

print(f"{Fore.GREEN}       ░▀█▀░█▀▄▀█░░░▄▀▀▄░█▀▀▄░▄▀▀▄░█░▒█░█▀▄░░░▀█▀░▄▀▀▄░░░█▀▀▄░█▀▀▄░█▀▀▄░▄▀▀▄░█░▒█░█▀▀▄░█▀▄░█▀▀░░░░{Style.RESET_ALL}")
print(f"{Fore.GREEN}       ░▒█░░█░▀░█░░░█▄▄█░█▄▄▀░█░░█░█░▒█░█░█░░░░█░░█░░█░░░█▄▄█░█░▒█░█░▒█░█░░█░█░▒█░█░▒█░█░░░█▀▀░░░░{Style.RESET_ALL}")
print(f"{Fore.GREEN}       ░▄█▄░▀░░▒▀░░░█░░░░▀░▀▀░░▀▀░░░▀▀▀░▀▀░░░░░▀░░░▀▀░░░░▀░░▀░▀░░▀░▀░░▀░░▀▀░░░▀▀▀░▀░░▀░▀▀▀░▀▀▀░░░░{Style.RESET_ALL}")




print(f"{Fore.GREEN}                       ██▓███   ██▀███   ▒█████   ▄▄▄██▀ ▓█████  ▄████▄ ▄▄▄█████▓{Style.RESET_ALL}")    
print(f"{Fore.GREEN}                     ▓██░  ██ ▓██ ▒ ██▒▒██▒  ██▒   ▒██  ▓█   ▀ ▒██▀ ▀█ ▓  ██▒ ▓▒{Style.RESET_ALL}")  
print(f"{Fore.GREEN}                     ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒   ░██  ▒███   ▒▓█    ▄▒ ▓██░ ▒░{Style.RESET_ALL}")
print(f"{Fore.GREEN}                     ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░▓██▄██▓ ▒▓█  ▄▒▒▓▓▄ ▄██░ ▓██▓ ░ {Style.RESET_ALL}") 
print(f"{Fore.GREEN}                     ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░ ▓███▒ ▒░▒████░▒ ▓███▀   ▒██▒ ░ {Style.RESET_ALL}")  
print(f"{Fore.GREEN}                     ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░  ▒▓▒▒░ ░░░ ▒░ ░░ ░▒ ▒    ▒ ░░   {Style.RESET_ALL}")  
print(f"{Fore.GREEN}                     ░▒ ░       ░▒ ░ ▒   ░    ▒ ▒░  ▒ ░▒░ ░ ░ ░     ░  ▒      ░ {Style.RESET_ALL}")

      
                     
print(f"{Fore.GREEN}                                                  ██▓ {Style.RESET_ALL}")
print(f"{Fore.GREEN}                                                  ▓██▒{Style.RESET_ALL}")
print(f"{Fore.GREEN}                                                  ▒██░{Style.RESET_ALL}") 
print(f"{Fore.GREEN}                                                  ▒██░{Style.RESET_ALL}")
print(f"{Fore.GREEN}                                                  ░██████{Style.RESET_ALL}")         
print(f"{Fore.GREEN}                                                   ░ ▒░▓{Style.RESET_ALL}")  

 

print("\033[1;32m[!]\033[0m \033[1;34mWelcome to Project L!\033[0m")


class LogsCommand(commands.Cog):
    def __init__(self, client):
        self.client = client


        

async def post(
    self,
    guild,
    type,
    user=None,
    target=None,
    reason=None,
    role=None,
    channel=None,
    before=None,
    after=None,
    content=None,
    media_urls=None  # Add a parameter for media URLs
):
    with open("Data/config.json", "r+", encoding="utf-8") as f:
        config = json.load(f)
        channelid = config["logs"]

    logschannel = self.client.get_channel(channelid)
    if logschannel is None:
        print("No logs channel configured.")
        return

    emb = discord.Embed(color=self.client.colour, timestamp=datetime.datetime.utcnow())
    emb.set_author(name=type, icon_url=None)
    if target is not None:
        emb.add_field(name="User", value=f"{target.mention} ({target.id})", inline=True)
    if user is not None:
        emb.add_field(name="Moderator", value=f"{user.mention} ({user.id})", inline=True)
    if before is not None:
        emb.add_field(name="Before", value=f"{before}", inline=False)
    if after is not None:
        emb.add_field(name="After", value=f"{after}", inline=False)
    if reason is not None:
        emb.add_field(name="Reason", value=f"{reason}", inline=False)
    if role is not None:
        emb.add_field(name="Role", value=f"{role}", inline=False)
    if channel is not None:
        emb.add_field(name="Channel", value=f"{channel}", inline=False)
    if content is not None:
        emb.add_field(name="Content", value=f"{content}", inline=False)

    # Check for media attachments
    if media_urls:
        media_field_value = "\n".join(media_urls)
        emb.add_field(name="Media Attachments", value=media_field_value, inline=False)

    await logschannel.send(content=f"ℹ️ **{type}**", embed=emb)
    return
    

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.Member):
        await asyncio.sleep(0.5)
        found_entry = None
        async for entry in guild.audit_logs(limit = 50, action = discord.AuditLogAction.ban, after = datetime.datetime.utcnow() - datetime.timedelta(seconds = 15), oldest_first = False):
            if entry.target.id == user.id:
                found_entry = entry
                break

        if found_entry is None:
            return
        
        await LogsCommand.post(self, guild=guild, type="User Banned", user=found_entry.user, target=user, reason=found_entry.reason)


    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.Member):
        await asyncio.sleep(0.5)
        found_entry = None
        async for entry in guild.audit_logs(limit = 50, action = discord.AuditLogAction.unban, after = datetime.datetime.utcnow() - datetime.timedelta(seconds = 15), oldest_first = False):
            if entry.target.id == user.id:
                found_entry = entry
                break
        if found_entry is None:
            return
        await LogsCommand.post(self, guild=guild, type="User Unbanned", user=found_entry.user, target=user, reason=found_entry.reason)


    @commands.Cog.listener()
    async def on_member_remove(self, user: discord.Member):
        await asyncio.sleep(0.5)
        found_entry = None
        async for entry in user.guild.audit_logs(limit = 50, action = discord.AuditLogAction.kick, after = datetime.datetime.utcnow() - datetime.timedelta(seconds = 10), oldest_first = False):
            if entry.target.id == user.id:
                found_entry = entry
                break
        if found_entry is None:
            return
        await LogsCommand.post(self, guild=user.guild, type="User Left", user=found_entry.user, target=user, reason=found_entry.reason)


    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.roles == after.roles:
            return
        await asyncio.sleep(0.5)
        found_entry = None
        async for entry in after.guild.audit_logs(limit = 50, action = discord.AuditLogAction.member_role_update, after = datetime.datetime.utcnow() - datetime.timedelta(seconds = 15), oldest_first = False):
            if entry.target.id == after.id:
                found_entry = entry
                break

        if found_entry is None:
            return
    
        role = None
        for role in after.roles:
            if role == "@everyone":
                continue
            if role not in before.roles:
                role = role.mention
                break
        if role is None:
            for role in before.roles:
                if role == "@everyone":
                    continue
                if role not in after.roles:
                    role = role.mention
                    break
            
        if role is None:
            return

        await LogsCommand.post(self, guild=after.guild, type="Member Roles Updated", user=found_entry.user, target=after, reason = found_entry.reason, role=role)



@commands.Cog.listener()
async def on_message_delete(self, message: discord.Message):
    content = message.content
    media_urls = [attachment.url for attachment in message.attachments]

    if not content and media_urls:
        content = "Media attachment(s) deleted."

    await LogsCommand.post(
        self,
        guild=message.guild,
        type="Message Deleted",
        target=message.author,
        channel=message.channel.mention,
        content=content,
        media_urls=media_urls  # Pass the media URLs to the post method
    )


    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if before.content == after.content:
            return
        await LogsCommand.post(self, guild=before.guild, type="Message Edited", target=before.author, channel=before.channel.mention, before=before.content, after=after.content)

    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        await asyncio.sleep(0.5)
        await LogsCommand.post(self, guild=role.guild, type="Role Created", role=role.mention)
            

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        await LogsCommand.post(self, guild=role.guild, type="Role Deleted", role=role.name)
    


async def setup(client):
    await client.add_cog(LogsCommand(client))