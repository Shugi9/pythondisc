import json
import discord
from discord.ext import commands
import time
import os
import asyncio
import requests
import random
import string
import sqlite3


class OnInteractionEvent(commands.Cog):
    def __init__(self, client):
        self.client = client


    def connect(self):
        try:
            conn = sqlite3.connect(f"Data/users.db")
            curs = conn.cursor()
            return conn, curs
        except Exception as exc:
            print(exc)
            return None


    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        with open("Data/config.json", "r+", encoding="utf-8") as f:
            config = json.load(f)
            transcriptsid = config["transcripts"]
            verifiedrole = config["verified"]
            voicecategory = config["voicecategory"]
            streammerrole = config["streamerrole"]


        if "custom_id" not in interaction.data:
            return
        elif interaction.guild is None:
            return

        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        class CloseView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(emoji="📄", label=f"Transcript", style=discord.ButtonStyle.grey, custom_id=f"transcript"))
                self.add_item(discord.ui.Button(emoji="🔒", label=f"Close", style=discord.ButtonStyle.grey, custom_id=f"close"))

        class CloseView2(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(emoji="🗑️", label=f"Delete", style=discord.ButtonStyle.grey, custom_id=f"delete"))
                self.add_item(discord.ui.Button(emoji="🔓", label=f"Reopen", style=discord.ButtonStyle.grey, custom_id=f"reopen"))
        
        if interaction.data['custom_id'] == "voicechannel":
            await interaction.response.defer(thinking=False, ephemeral=True)
            member = interaction.guild.get_member(interaction.user.id)
            role = interaction.guild.get_role(streammerrole)
            if role not in member.roles:
                await interaction.followup.send(f"You don't have the streamer role!", ephemeral=True)
                return
            
            category = interaction.guild.get_channel(voicecategory)
            if category is None:
                await interaction.followup.send(f"Category not found.", ephemeral=True)
                return
            

            result = self.connect()
            if result is None:
                return

            userid = interaction.user.id

            conn, curs = result
            query = f"""SELECT voice FROM users WHERE userid={userid}"""
            curs.execute(query)
            records = curs.fetchall()
            if len(records) > 0:
                channelid = records[0][0]
                chan = self.client.get_channel(channelid)
                if chan is not None:
                    await interaction.followup.send(f"You already have a private voice channel: {chan.mention}", ephemeral=True)
                    return
            
            channel = await interaction.guild.create_voice_channel(name=interaction.user.name, category=category)
            await channel.set_permissions(member, administrator=True, manage_channels=True, connect=True, mute_members=True)
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            query = f"""UPDATE users SET (voice) = ({channel.id}) WHERE userid={userid}"""
            curs.execute(query)
            conn.commit()
            conn.close()
            await interaction.followup.send(f"Your private voice channel: {channel.mention}", ephemeral=True)
            return


        elif interaction.data['custom_id'] == "modmail_del":
            await interaction.response.send_message("Deleting modmail channel in 3 seconds")
            await asyncio.sleep(3)
            await interaction.channel.delete()
            return



        elif interaction.data['custom_id'] == "roles":
            with open("Data/roles.json", "r+", encoding="utf-8") as f:
                roles = json.load(f)

            try:
                num = int(interaction.data['values'][0].split(".")[0]) - 1
                roleid = roles[num]
                role = interaction.guild.get_role(roleid)
            except Exception as exc:
                print(exc)
                await interaction.response.send_message("Role does not exist.", ephemeral=True)
                return
            if role is None:
                await interaction.response.send_message("Role does not exist.", ephemeral=True)
                return
            
            
            member = interaction.guild.get_member(interaction.user.id)
            if role not in member.roles:
                try:
                    await member.add_roles(role)
                    await interaction.response.send_message(f"You received {role.mention}", ephemeral=True)
                except Exception as exc:
                    await interaction.response.send_message("Could not give this role.", ephemeral=True)
                    return
            else:
                try:
                    await member.remove_roles(role)
                    await interaction.response.send_message(f"You no longer have {role.mention}", ephemeral=True)
                except Exception as exc:
                    await interaction.response.send_message("Could not remove this role.", ephemeral=True)
                    return
                
        elif interaction.data['custom_id'].startswith("verify"):
            role = interaction.guild.get_role(verifiedrole)
            if role is None:
                await interaction.response.send_message(f"Something went wrong.", ephemeral=True)
                return
            
            member = interaction.guild.get_member(interaction.user.id)
            if role in member.roles:
                await interaction.response.send_message(f"You are already verified!", ephemeral=True)
                return
            else:
                try:
                    await member.add_roles(role)
                    await interaction.response.send_message(f"Verified!", ephemeral=True)
                    unverified = interaction.guild.get_role(unverified)
                    if unverified is not None:
                        if unverified in member.roles:
                            await member.remove_roles(unverified)
                            return
                    return
                except Exception as exc:
                    await interaction.response.send_message(f"Unable to verify.", ephemeral=True)
                    return
                
        elif interaction.data['custom_id'].startswith("ticket_"):
            tickettype = interaction.data['custom_id'].split("_")[1]
            categoryid = config["tickets"][f"category_{tickettype}"]
            ticketcat = interaction.guild.get_channel(categoryid)
            print(f"Ticket Type: {tickettype}")
            print(f"Category ID: {categoryid}")
            print(f"Category Object: {ticketcat}")



            ticketchannel = await interaction.guild.create_text_channel(name=f"ticket-{interaction.user.name}", category=ticketcat)
            await ticketchannel.set_permissions(interaction.user, view_channel=True, send_messages=True, read_messages=True)
            await ticketchannel.set_permissions(interaction.user, view_channel=True, send_messages=True, read_messages=True)
            await ticketchannel.set_permissions(interaction.user, view_channel=True, send_messages=True, read_messages=True)
            await interaction.response.send_message(f"{tickettype.capitalize()} ticket created! {ticketchannel.mention}", ephemeral=True)
            emb = discord.Embed(description=f"Welcome, {interaction.user.mention}\n\nPlease wait for support", colour=self.client.colour)
            emb.set_author(name=f"{tickettype.capitalize()} Ticket {interaction.user}", icon_url=userpfp)
            await ticketchannel.send(embed=emb, view=CloseView())

            print(f"Ticket Channel Properties:")
            print(f"Channel ID: {ticketchannel.id}")
            print(f"Channel Name: {ticketchannel.name}")
            print(f"Channel Category ID: {ticketchannel.category_id}")
            print(f"Channel Category Object: {ticketchannel.category}")

            return
        


        elif interaction.data['custom_id'].startswith("transcript"):
            rs = requests.Session()
            ticketopener = interaction.message.embeds[0].author.name.split("Ticket ")[1]
            nums = "".join(random.choices(string.digits, k=3))
            await interaction.response.defer(thinking=True)

            try:
                open(f"Transcripts/ticket{nums}-{ticketopener}.txt", "x", encoding="utf-8").close()
            except FileExistsError:
                pass
            with open(f"Transcripts/ticket{nums}-{ticketopener}.txt", "r+",
                      encoding="utf-8") as f1:

                f1.write(
                    f"[!] Ticket opened by {ticketopener}\n[!] Opened at: {str(interaction.message.created_at)[:16]}\n\n\n")
                async for msg in interaction.channel.history(limit=500, oldest_first=True):
                    if msg.author.id == self.client.user.id:
                        continue
                    else:
                        attlist = []
                        for att in msg.attachments:
                            source = rs.post(
                                f"https://api.imgbb.com/1/upload?key=6f5e57b70100077bfb6b4adbc58a3015&image={att.url.split('?')[0]}")
                            if source.status_code != 200:
                                continue
                            try:
                                src = source.json()
                                attlist.append(src["data"]["url"])
                            except Exception:
                                continue

                        attlist = str(attlist).replace("'", "")

                        f1.write(
                            f"\n* {str(msg.created_at)[:16]} - {msg.author}:\n{msg.content}\nAttachments: {attlist}\n\n")

                f1.write(
                    f"\n\n[!] Ticket closed by {interaction.user}\n[!] Closed at: {str(interaction.created_at)[:16]}")

            try:
                logfile = discord.File(f"Transcripts/ticket{nums}-{ticketopener}.txt",
                                       filename=f"ticket{nums}-{ticketopener}.txt")
                logchan = self.client.get_channel(transcriptsid)
                if logchan is not None:
                    await logchan.send(
                        f"**Ticket {ticketopener}**\n\n**Closed by: **{interaction.user}\n**Closed at: **{str(interaction.created_at)[:16]}\n**Transcript:** ticket{nums}-{ticketopener}.txt",
                        file=logfile)

                logfile.close()
                os.remove(f"Transcripts/ticket{nums}-{ticketopener}.txt")
                await interaction.followup.send(f"Transcript saved by {interaction.user.mention} - {logchan.mention}")
            except Exception as exc:
                await interaction.followup.send(f"Transcript could not be saved.")
                return exc


        elif interaction.data['custom_id'].startswith("close"):
            emb = discord.Embed(description=f"Ticket closed by {interaction.user.mention}", colour=self.client.colour)
            emb.set_author(name=interaction.message.embeds[0].author.name, icon_url=interaction.message.embeds[0].author.icon_url)
            await interaction.response.send_message(embed=emb, view=CloseView2())

            authors = []
            async for msg in interaction.channel.history(limit=500):
                if msg.author not in authors:
                    if interaction.channel.permissions_for(msg.author).kick_members is not True:
                        authors.append(msg.author)

            for author in authors:
                await interaction.channel.set_permissions(author, send_messages=False, read_messages=True)
            
            return

        elif interaction.data['custom_id'].startswith("delete"):
            await interaction.response.send_message(f"Ticket will be deleted in 10 seconds. Deleted by {interaction.user.mention}")
            await asyncio.sleep(10)
            await interaction.channel.delete()
            return


        elif interaction.data['custom_id'].startswith("reopen"):
            part = interaction.channel.overwrites_for(interaction.user)
            if part.send_messages is False:
                await interaction.response.send_message(f"Only admins can reopen tickets.", ephemeral=True)
                return
            
            await interaction.response.send_message(f"Ticket Reopened by {interaction.user.mention}")

            authors = []
            async for msg in interaction.channel.history(limit=500):
                if msg.author not in authors:
                    if interaction.channel.permissions_for(msg.author).kick_members is not True:
                        authors.append(msg.author)

            for author in authors:
                await interaction.channel.set_permissions(author, send_messages=True, read_messages=True)
            
            return
        




async def setup(client):
    await client.add_cog(OnInteractionEvent(client))