import json
import discord
from discord import app_commands
from discord.ext import commands, tasks
import time
import os
import asyncio
import sqlite3
import datetime
import random
import numpy
import traceback



class EconomyCommand(commands.Cog):
    def __init__(self, client):
        self.client = client


    def connect(self):
        try:
            conn = sqlite3.connect(f"Data/users.db")
            curs = conn.cursor()
            return conn, curs
        except Exception as exc:
            print(exc)
            return None


    def cooldown(self, remaining):
        if remaining < 60:
            remaining = round(remaining)
            return f"{remaining} second{'' if remaining == 1 else 's'}"
        elif remaining < 3600:
            remaining = round(remaining / 60)
            return f"{remaining} minute{'' if remaining == 1 else 's'}"
        else:
            remaining = round(remaining / 3600)
            return f"{remaining} hour{'' if remaining == 1 else 's'}"


    @app_commands.command(name="dice", description=f"Roll a 50% dice")
    async def dice(self, interaction: discord.Interaction, bet: app_commands.Range[int, 1, 1000000]):
        userid = interaction.user.id
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()

            emb = discord.Embed(colour=discord.Colour.red())
            emb.set_author(name=f"Insufficient Balance", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
    	
        balance = records[0][0]

        if bet > balance:
            emb = discord.Embed(colour=discord.Colour.red())
            emb.set_author(name=f"Insufficient Balance", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        
        roll = random.randrange(1, 100)
        if roll < 50:
            balance -= bet
            emb = discord.Embed(colour=discord.Colour.red())
            # emb.add_field(name="Bet", value=f"${bet}", inline=True)
            emb.add_field(name="Profit", value=f"-${bet}", inline=True)
            emb.set_author(name=f"{roll}/100", icon_url=userpfp)

        else:
            balance += bet
            emb = discord.Embed(colour=discord.Colour.green())
            # emb.add_field(name="Bet", value=f"${bet}", inline=True)
            emb.add_field(name="Profit", value=f"${bet}", inline=True)
            emb.set_author(name=f"{roll}/100", icon_url=userpfp)

        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        await interaction.response.send_message(embed=emb)
        return
    

    @dice.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)
        

    @app_commands.command(name="rob", description="Rob another user")
    @app_commands.checks.cooldown(10, 180, key=lambda i: i.user.id)
    async def rob(self, interaction: discord.Interaction, member: discord.Member):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar
        
        userid = interaction.user.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            balance = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
        else:
            balance = records[0][0]

        userid1 = member.id

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid1}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            balance1 = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid1}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
        else:
            balance1 = records[0][0]

        rob = random.choice([True, False])
        if rob is False:
            arr = random.choice([True, False])
            if arr is False:
                await interaction.response.send_message(f"{member.mention} got away! Robbery failed.")
                return
            else:
                fine = random.choice([10, 20, 30])
                balance -= fine
                if balance < 0:
                    balance = 0

                query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
                curs.execute(query)
                conn.commit()
                conn.close()

                await interaction.response.send_message(f"{member.mention} called the police! You have been fined **${fine}** for robbery")
                return

        if balance1 == 0:
            await interaction.response.send_message(f"{member.mention} got lucky and had **$0** in his wallet.")
            return
        
        num = random.randrange(10, 40)
        if balance1 < num:
            num = balance1

        balance1 -= num
        balance += num


        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        query = f"""UPDATE users SET (balance) = ({balance1}) WHERE userid={userid1}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        await interaction.response.send_message(f"You robbed {member.mention} and received **${num}**")
        return
    

    @rob.error 
    async def catch(self, interaction, error):
        if isinstance(error, app_commands.CommandOnCooldown):
            wait = self.cooldown(error.retry_after)
            await interaction.response.send_message(f"Wait **{wait}** before you can rob again", ephemeral=True)
            return
        
        print(error)
        

    @app_commands.command(name="work", description="Work and receive rewards")
    @app_commands.checks.cooldown(1, 300, key=lambda i: i.user.id)
    async def work(self, interaction: discord.Interaction):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar
        
        userid = interaction.user.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()
        amount = random.randrange(10, 100)

        if len(records) == 0:
            balance = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
        else:
            balance = records[0][0]

        balance += amount
        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        emb = discord.Embed(description=f"You received **${amount}**", colour=discord.Colour.green())
        emb.set_author(name=f"Work", icon_url=userpfp)
        await interaction.response.send_message(embed=emb)
        return
    

    @work.error 
    async def catch(self, interaction, error):
        if isinstance(error, app_commands.CommandOnCooldown):
            wait = self.cooldown(error.retry_after)
            await interaction.response.send_message(f"Wait **{wait}** before you can work again", ephemeral=True)
            return
        
        print(error)


    @app_commands.command(name="daily", description="Claim a free daily reward")
    @app_commands.checks.cooldown(1, 86400, key=lambda i: i.user.id)
    async def daily(self, interaction: discord.Interaction):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar
        
        userid = interaction.user.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result

        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()
        amount = random.randrange(100, 250)

        if len(records) == 0:
            balance = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
        else:
            balance = records[0][0]

        balance += amount
        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        emb = discord.Embed(description=f"You received **${amount}**", colour=discord.Colour.green())
        emb.set_author(name=f"Daily Reward", icon_url=userpfp)
        await interaction.response.send_message(embed=emb)
        return
    

    @daily.error 
    async def catch(self, interaction, error):
        if isinstance(error, app_commands.CommandOnCooldown):
            wait = self.cooldown(error.retry_after)
            await interaction.response.send_message(f"Wait **{wait}** before you can claim your daily reward.", ephemeral=True)
            return
        
        print(error)
        

    @app_commands.command(name="bet", description="Bet against someone else")
    async def bet(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1000000]):
        userid = interaction.user.id
        userid1 = member.id
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        if member.avatar is None:
            userpfp1 = member.default_avatar
        else:
            userpfp1 = member.avatar

        if interaction.user == member:
            await interaction.response.send_message(f"You can't bet against yourself", ephemeral=True)
            return

        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()

            await interaction.response.send_message(f"You don't have **${amount}**", ephemeral=True)
            return
        
        balance = records[0][0]
        if balance <= amount:
            await interaction.response.send_message(f"You don't have **${amount}**", ephemeral=True)
            return


        query = f"""SELECT balance FROM users WHERE userid={userid1}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid1}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()

            await interaction.response.send_message(f"{member.mention} does not have **${amount}**", ephemeral=True)
            return
        

        balance1 = records[0][0]
        if balance1 <= amount:
            await interaction.response.send_message(f"{member.mention} does not have **${amount}**", ephemeral=True)
            return
        





        class ChoiceView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)

            @discord.ui.button(emoji="✅", label="Accept", custom_id=f"accept")
            async def accept(self, inter: discord.Interaction, button: discord.Button):
                if inter.user.id != member.id:
                    await inter.response.send_message("This request is not for you.", ephemeral=True)
                    return
                
                try:
                    conn = sqlite3.connect(f"Data/users.db")
                    curs = conn.cursor()
                    partlist = [interaction.user, member]
                    winner = random.choice(partlist)
                    partlist.remove(winner)
                    loser = partlist[0]
                    
                    query = f"""SELECT balance FROM users WHERE userid={winner.id}"""
                    curs.execute(query)
                    records = curs.fetchall()
                    winbalance = records[0][0]

                    query = f"""SELECT balance FROM users WHERE userid={loser.id}"""
                    curs.execute(query)
                    records = curs.fetchall()
                    losbalance = records[0][0]

                    winbalance += amount
                    losbalance -= amount

                    query = f"""UPDATE users SET (balance) = ({winbalance}) WHERE userid={winner.id}"""
                    curs.execute(query)
                    query = f"""UPDATE users SET (balance) = ({losbalance}) WHERE userid={loser.id}"""
                    curs.execute(query)
                    conn.commit()
                    conn.close()

                    emb = inter.message.embeds[0]
                    emb.colour = discord.Colour.green()
                    emb.add_field(name="Winner", value=winner.mention, inline=False)
                    emb.set_footer(text=None)
                    await inter.response.edit_message(embed=emb, view=None)      
                    return
                except Exception as exc:
                    print(traceback.format_exc())

            
            @discord.ui.button(emoji="❌", label="Decline", custom_id=f"decline")
            async def decline(self, inter: discord.Interaction, button: discord.Button):
                if inter.user.id != member.id:
                    await inter.response.send_message("This request is not for you.", ephemeral=True)
                    return
                
                await inter.message.delete()
                return
        

        emb = discord.Embed(title="Bet Request", colour=discord.Colour.grey())
        emb.add_field(name="From", value=interaction.user.mention, inline=False)
        emb.add_field(name="Amount", value=f"${amount}", inline=False)
        emb.set_author(name=member, icon_url=userpfp1)
        emb.set_footer(text="Expires in 3 minutes")


        await interaction.response.send_message(embed=emb, view=ChoiceView())
        return


    @bet.error 
    async def catch(self, interaction, error):
        print(error)


    @app_commands.command(name="crash", description="Play a game of crash")
    async def crash(self, interaction: discord.Interaction, bet: app_commands.Range[int, 1, 1000000], cashout: app_commands.Range[float, 1.01, 100.0]):
        cash = cashout
        userid = interaction.user.id
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar

        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()

            emb = discord.Embed(colour=discord.Colour.red())
            emb.set_author(name=f"Insufficient Balance", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        
        balance = records[0][0]
        if bet > balance:
            emb = discord.Embed(colour=discord.Colour.red())
            emb.set_author(name=f"Insufficient Balance", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        
        balance -= bet
        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()

        nums = numpy.random.exponential(scale=4, size=4)
        print(nums)
        x = round(random.choice(nums), 2)
        if x < cash:  # loss
            emb = discord.Embed(title=f"{1.00 if x <= 1 else x}x", colour=discord.Colour.red())
            emb.add_field(name="Bet", value=f"${bet}", inline=True)
            emb.add_field(name="Profit", value=f"-${bet}", inline=True)
            emb.add_field(name="Cashout", value=f"{cash}x", inline=False)
            emb.set_author(name=f"Loss", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        else:  # win 
            add = cash * bet
            balance += add
            query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
            curs.execute(query)
            conn.commit()

            emb = discord.Embed(title=f"{1.00 if x <= 1 else x}x", colour=discord.Colour.green())
            emb.add_field(name="Bet", value=f"${bet}", inline=True)
            emb.add_field(name="Profit", value=f"${round(add, 2)}", inline=True)
            emb.add_field(name="Cashout", value=f"{cash}x", inline=False)
            emb.set_author(name=f"Win", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
    

    @crash.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)




        

        


    @app_commands.command(name="leaderboard", description="Displays the top 10 richest users")
    async def leaderboard(self, interaction: discord.Interaction):
        if interaction.user.avatar is None:
            userpfp = interaction.user.default_avatar
        else:
            userpfp = interaction.user.avatar
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result

        query = f"""SELECT userid, balance FROM users ORDER BY balance DESC LIMIT 10;"""
        curs.execute(query)
        records = curs.fetchall()
        conn.close()

        if len(records) == 0:
            emb = discord.Embed(description="No users found", colour=self.client.colour)
            emb.set_author(name="Leaderboard", icon_url=userpfp)
            emb.set_image(url=self.client.greenline)
            await interaction.response.send_message(embed=emb)
            return
        
        text = ""
        for index, record in enumerate(records):
            userid, balance = record
            text += f"**{index + 1}.** <@{userid}> - ``${round(balance)}``\n"

        emb = discord.Embed(description=text, colour=self.client.colour)
        emb.set_author(name="Leaderboard", icon_url=userpfp)
        emb.set_image(url=self.client.greenline)
        await interaction.response.send_message(embed=emb)
        return
    

    @leaderboard.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)
    


    @app_commands.command(name="send", description="Send someone else money")
    @app_commands.checks.has_permissions(administrator=True)
    async def send(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 100000]):
        userid = interaction.user.id
        userid1 = member.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            balance = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()
        else:
            balance = records[0][0]

        if balance < amount:
            await interaction.response.send_message("Insufficient Balance", ephemeral=True)
            return
        
        balance -= amount
        query = f"""UPDATE users SET (balance) = ({balance}) WHERE userid={userid}"""
        curs.execute(query)
        
        
        query = f"""SELECT balance FROM users WHERE userid={userid1}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            balance1 = 0
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid1}, 0, 0, 0)"""
            curs.execute(query)
        else:
            balance1 = records[0][0]

        balance1 += amount
        query = f"""UPDATE users SET (balance) = ({balance1}) WHERE userid={userid1}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        await interaction.response.send_message(f"You sent **${amount}** to {member.mention}")
        return


    @send.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)

    
    @app_commands.command(name="balance", description="Shows how much money you have")
    @app_commands.describe(
        member="Show somebody else's balance"
    )
    async def balance(self, interaction: discord.Interaction, member: discord.Member = None):
        if member is not None:
            user = member
            userid = member.id
            if member.avatar is None:
                userpfp = member.default_avatar
            else:
                userpfp = member.avatar
        else:
            user = interaction.user
            userid = interaction.user.id
            if interaction.user.avatar is None:
                userpfp = interaction.user.default_avatar
            else:
                userpfp = interaction.user.avatar

        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, 0, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()

            emb = discord.Embed(description=f"**$0**", colour=self.client.colour)
            emb.set_author(name=f"{user}", icon_url=userpfp)
            await interaction.response.send_message(embed=emb)
            return
        
        balance = records[0][0]
        conn.close()
        emb = discord.Embed(description=f"**${round(balance, 2)}**", colour=self.client.colour)
        emb.set_author(name=f"{user}", icon_url=userpfp)
        await interaction.response.send_message(embed=emb)
        return
    

    @balance.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)


    @app_commands.command(name="addmoney", description="Add money to a user (Admin)")
    @app_commands.checks.has_permissions(administrator=True)
    async def addmoney(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 100000]):
        userid = member.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, {amount}, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()
            await interaction.response.send_message(f"Added **${amount}** to {member.mention}")
            return
        
        bal = records[0][0]
        bal += amount
        query = f"""UPDATE users SET (balance) = ({bal}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        await interaction.response.send_message(f"Added **${amount}** to {member.mention}")
        return


    @addmoney.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)

    @app_commands.command(name="removemoney", description="Remove money from a user (Admin)")
    @app_commands.checks.has_permissions(administrator=True)
    async def removemoney(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 100000]):
        userid = member.id
        result = self.connect()
        if result is None:
            await interaction.response.send_message("Something went wrong, contact support. (Code 3)", ephemeral=True)
            return

        conn, curs = result
        query = f"""SELECT balance FROM users WHERE userid={userid}"""
        curs.execute(query)
        records = curs.fetchall()

        if len(records) == 0:
            query = f"""INSERT INTO users(userid, balance, invited, left) VALUES({userid}, {amount}, 0, 0)"""
            curs.execute(query)
            conn.commit()
            conn.close()
            await interaction.response.send_message(f"{member.mention} has **$0**")
            return
        
        bal = records[0][0]
        bal -= amount
        if bal < 0:
            bal = 0
        query = f"""UPDATE users SET (balance) = ({bal}) WHERE userid={userid}"""
        curs.execute(query)
        conn.commit()
        conn.close()

        await interaction.response.send_message(f"Removed **${amount}** from {member.mention}")
        return


    @removemoney.error 
    async def catch(self, interaction, error):
        print(error)
        raise(error)


        



async def setup(client):
    await client.add_cog(EconomyCommand(client))