import json
import discord
from discord import app_commands
from discord.ext import commands
import time
import os
import asyncio
import requests



class PanelsCommand(commands.Cog):
    def __init__(self, client):
        self.client = client


    @app_commands.command(name="reactionroles", description="Send configured reaction roles panel (Admin only)")
    @app_commands.checks.has_permissions(administrator=True)
    async def reactionroles(self, interaction: discord.Interaction):
        with open("Data/roles.json", "r+", encoding="utf-8") as f:
            roles = json.load(f)

        class DropdownMenu(discord.ui.Select):
            def __init__(self, options):
                super().__init__(placeholder=f"Select a role.", min_values=1, max_values=1,
                                 options=options, custom_id="roles")


        class DropdownView(discord.ui.View):
            def __init__(self, options):
                super().__init__(timeout=None)
                self.add_item(DropdownMenu(options))


        optionlist = []
        num = 0
        for option in roles:
            role = interaction.guild.get_role(option)
            if role is None:
                continue
            
            num += 1
            optionlist.append(discord.SelectOption(
                emoji="👤",
                label=f"{num}. {role.name}",
                description=f""
            ))
        
        if len(optionlist) == 0:
            await interaction.response.send_message("No roles are configured.", ephemeral=True)
            return

        await interaction.response.send_message("Reaction roles panel sent", ephemeral=True)
        emb = discord.Embed(title=f"Reaction Roles", description=f"Receive your roles here.",
                            colour=self.client.colour)
        emb.set_image(url=self.client.greenline)
        await interaction.channel.send(embed=emb, view=DropdownView(optionlist))
        return


    @app_commands.command(name="verifypanel", description="Sends verify panel (Admin only)")
    @app_commands.checks.has_permissions(administrator=True)
    async def verifypanel(self, interaction: discord.Interaction):
        
        class VerifyView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(emoji="✅", label=f"Verify", style=discord.ButtonStyle.grey, custom_id=f"verify", disabled=False))

        await interaction.response.send_message("Verify panel sent", ephemeral=True)
        emb1 = discord.Embed(colour=self.client.colour)
        emb1.set_image(url="https://i.ibb.co/Zg2csC5/welcome.gif")

        emb2 = discord.Embed(title="<a:green_crown:1105699034749992982> Welcome to Lygo's Land Discord Server <a:green_crown:1105699034749992982>", description=f"<a:green_dsd:1105696364609929216> This server is completely based around Gaming & Community you guys can interact with each other and fun <a:green_dsd:1105696364609929216>\n\n<a:green_fire:1105696590557093948> Despite that, anyone is welcome to join the community and have a fun time. Personalize your server profile & take suitable roles for yourself — Check out ⁠✨〢ꜱᴇʟꜰ-ʀᴏʟᴇꜱ <a:green_fire:1105696590557093948>", colour=self.client.colour)
        emb2.set_image(url=self.client.greenline)

        emb3 = discord.Embed(description=f"<a:green_arrow:1105701292036325416> For additional questions or to contact the support team please open a ticket from ⁠❓〢ᴛɪᴄᴋᴇᴛ and the staff team get back to you as soon as they can. <a:green_arrowleft:1105696390744649822>", colour=self.client.colour)
        emb3.set_image(url=self.client.greenline)
        # emb3.add_field(name="<7a833636820f45009448b5ddf288f705:1078711266593493103> Official Links!", value=f"")


        emb4 = discord.Embed(title=f"<a:green_crown:1105699034749992982> Server Verification! <a:green_crown:1105699034749992982>", description=f"**<a:green_dsd:1105696364609929216> Click the Verify button below This will grant you access tothe rest of the server! <a:green_dsd:1105696364609929216>**",
                            colour=self.client.colour)
        emb4.set_image(url="https://i.ibb.co/1QcjMWG/verify.gif")
        await interaction.channel.send(embeds=[emb1, emb2, emb3, emb4], view=VerifyView())
        return
    

    @app_commands.command(name="voicepanel", description="Sends voice channel panel (Admin only)")
    @app_commands.checks.has_permissions(administrator=True)
    async def voicepanel(self, interaction: discord.Interaction):
        
        class VerifyView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(emoji="🔊", label=f"Create VC", style=discord.ButtonStyle.grey, custom_id=f"voicechannel", disabled=False))

        await interaction.response.send_message("Voice channel panel sent", ephemeral=True)
        emb = discord.Embed(title=f"Voice Channels", description=f"Click here to create a voice channel (Streamer only)",
                            colour=self.client.colour)
        emb.set_image(url="https://i.ibb.co/BVTKyXb/greenline.gif")
        await interaction.channel.send(embed=emb, view=VerifyView())
        return



    @app_commands.command(name="ticketpanel", description="Sends ticket panel (admin only)")
    @app_commands.checks.has_permissions(administrator=True)
    async def ticketpanel(self, interaction: discord.Interaction):
        class TicketView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(emoji="👥", label=f"Help", style=discord.ButtonStyle.grey, custom_id=f"ticket_help", disabled=False))
                self.add_item(discord.ui.Button(emoji="📬", label=f"Suggestions", style=discord.ButtonStyle.grey, custom_id=f"ticket_suggestions", disabled=False))
                self.add_item(discord.ui.Button(emoji="⛔", label=f"Report Staff", style=discord.ButtonStyle.grey, custom_id=f"ticket_report", disabled=False))

        await interaction.response.send_message("Panel sent", ephemeral=True)
        emb = discord.Embed(title=f"Tickets", description=f"To contact the support team click a button below to open a ticket.",
                            colour=self.client.colour)
        emb.set_image(url=self.client.greenline)
        

        await interaction.channel.send(embed=emb, view=TicketView())
        return


    




async def setup(client):
    await client.add_cog(PanelsCommand(client))