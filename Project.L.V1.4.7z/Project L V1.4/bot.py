import json
import discord
from discord.ext import commands, tasks
import asyncio
import os
import time
import datetime
import sqlite3
import random
import scrapetube
import requests
from easy_pil import Editor, load_image_async, Font
from Commands.members import mAddBtn


with open("Data/config.json", "r+", encoding="utf-8") as f:
    config = json.load(f)
    token = config["token"]
    welcomeid = config["welcome"]
    welcome_image_id = config["welcome_images"]
    botclientid = config["client_id"]
    youtubeid = config["youtube"]
    twitchid = config["twitch"]
    modmailid = config["modmail"]
    ytchannel = config["ytchannel"]
    twchannel = config["twchannel"]
    clientid = config["clientid"]
    clientsecret = config["clientsecret"]

previous = []
notified = []

try:
    videos = scrapetube.get_channel(
        ytchannel, sort_by="newest", limit=3, content_type="videos")
    time.sleep(1)
    shorts = scrapetube.get_channel(
        ytchannel, sort_by="newest", limit=3, content_type="shorts")
    time.sleep(1)
    lives = scrapetube.get_channel(
        ytchannel, sort_by="newest", limit=3, content_type="streams")
except Exception as exc:
    print(f"[!] Error, {exc}")
    quit()

for results in [videos, shorts, lives]:
    for result in results:
        if result['videoId'] not in previous:
            previous.append(result['videoId'])

client = commands.Bot(command_prefix="!", intents=discord.Intents.all(), help_command=None, status=discord.Status.online,
                      activity=discord.Activity(type=discord.ActivityType.playing, name="/help"), application_id=botclientid)


def sticky_ready(id, content):
    @tasks.loop(seconds=12)
    async def stickyloop(channel: discord.TextChannel, message: str):
        print(message)
        if channel.id not in client.sticky:
            stickyloop.stop()
            return

        elif client.sticky[channel.id] != message:
            stickyloop.stop()
            return

        msgz = []
        async for msg in channel.history(limit=20, oldest_first=False):
            msgz.append(msg.content)

        if message not in msgz:
            await channel.send(f"{message}")
    client.sticky[id] = content
    c = client.get_channel(id)
    stickyloop.start(c, content)


@client.event
async def on_ready():

    print(f"\033[92m[!]\033[0m \033[94m{time.strftime('%Y-%m-%d - %H:%M')}: Initiating bot. Please wait...\033[0m", end='', flush=True)
    # while not youtubeloop.is_running() or not twitchloop.is_running() or not checker.is_running():
    #     await asyncio.sleep(1)

    print("\n\033[92m[!]\033[0m \033[94mBot is online\033[0m")
    print(f"\033[92m[!]\033[0m \033[94mLogged in as: {client.user} - {client.user.id}\033[0m")
    conn = sqlite3.connect(f"sticky.db")
    cursor = conn.cursor()
    values = cursor.execute("SELECT * FROM infos_salons").fetchall()
    print(values)
    for i in values:
        if i[1] != "":
            sticky_ready(i[0], i[1])
    conn = sqlite3.connect('Data/user.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM roles')
    values = cursor.fetchall()
    print(values)
    try:
        for i in values:
            client.add_view(mAddBtn(content=i[4], emoji=i[3], role=discord.Object(id=i[2])))
    except Exception as e:
        print(e)

    # if not youtubeloop.is_running():
    #     youtubeloop.start()

    # if not twitchloop.is_running():
    #     twitchloop.start()

    # if not checker.is_running():
    #     checker.start()


@tasks.loop(seconds=30)
async def checker():
    conn = sqlite3.connect(f"Data/users.db")
    curs = conn.cursor()
    nower = int(str(time.time()).split(".")[0])
    run = f"SELECT id, channel, message FROM giveaways WHERE ends<={nower} AND ended=0"
    curs.execute(run)
    records = curs.fetchall()

    for part in records:
        giveawayid = part[0]
        query = f"""UPDATE giveaways SET (ended) = (1) WHERE id={giveawayid}"""
        curs.execute(query)
        conn.commit()

        channelid = part[1]
        messageid = part[2]
        channel = client.get_channel(channelid)
        if channel is None:
            query = f"""DELETE FROM giveaways WHERE id={giveawayid} AND channel={channelid}"""
            curs.execute(query)
            conn.commit()
            conn.close()
            return
        message = await channel.fetch_message(messageid)
        if message is None:
            query = f"""DELETE FROM giveaways WHERE id={giveawayid} AND message={messageid}"""
            curs.execute(query)
            conn.commit()
            conn.close()
            return

        if "Giveaway ended" in message.embeds[0].description:
            return

        prize = message.embeds[0].title
        winners = int(message.embeds[0].description.split(
            "Winners:** ")[1].split("**Ends")[0].replace("\n", "").replace(r"\n", ""))

        choices = []
        for r in message.reactions:
            if r.emoji == "🎉":
                async for user in r.users():
                    if user.id == client.user.id:
                        continue
                    choices.append(user)

                break

        if len(choices) < winners:
            await message.reply(f"Not enough participants for this giveaway.")
            return

        winnerlist = random.choices(choices, k=winners)
        winnerz = []
        for winner in winnerlist:
            winnerz.append(winner.mention)

        winnerz = str(winnerz).replace(
            "[", "").replace("]", "").replace("'", "")

        ember = message.embeds[0]
        ember.description = f'{message.embeds[0].description.split("React with")[0]}Giveaway ended.'
        await message.edit(embed=ember)

        emb = discord.Embed(title=prize, colour=discord.Colour.green())
        emb.add_field(name="Winners", value=winnerz, inline=False)
        emb.set_footer(text="Giveaway ended")
        await message.reply(embed=emb)
        continue


@tasks.loop(seconds=60)
async def twitchloop():
    channel: discord.TextChannel = client.get_channel(twitchid)
    if channel is None:
        print("Invalid channel configured.")
        return

    rs = requests.Session()
    body = {
        'client_id': clientid,
        'client_secret': clientsecret,
        "grant_type": 'client_credentials'
    }
    r = rs.post('https://id.twitch.tv/oauth2/token', body)
    keys = r.json()
    token = keys['access_token']

    # Check your Twitch channel
    url = "https://api.twitch.tv/helix/streams?user_login=" + twchannel
    headers = {
        'Client-ID': clientid,
        'Authorization': 'Bearer ' + token
    }

    req = requests.get(url, headers=headers)
    res = req.json()

    if len(res['data']) > 0:
        data = res['data'][0]
        streamid = data["id"]
        if streamid not in notified:
            notified.append(streamid)

            # Fetch game information directly from the API response
            game_name = data["game_name"]

            # Print the entire data for debugging
            print(f"Debug - Twitch API Data: {data}")

            # Construct the message including the game name
            message = f"**<@&1039329011173699734> I'm Live** \n🚨https://www.twitch.tv/{twchannel} 🚨"
            if game_name:
                message += f"\nPlaying: {game_name}"
            message += " 👍"
            await channel.send(message)


    # Add your friend's Twitch channel here
    friend_twitch_channel = "sirlygophobia"
    friend_url = f"https://api.twitch.tv/helix/streams?user_login={friend_twitch_channel}"

    friend_req = requests.get(friend_url, headers=headers)
    friend_res = friend_req.json()

    if len(friend_res['data']) > 0:
        friend_data = friend_res['data'][0]
        friend_stream_id = friend_data["id"]
        if friend_stream_id not in notified:
            notified.append(friend_stream_id)

            # Fetch game information directly from the API response
            game_name = friend_data["game_name"]

            # Print the entire data for debugging
            print(f"Debug - Twitch API Data (Friend): {friend_data}")

            # Construct the message including the game name
            message = f"**'{friend_twitch_channel}' is Live**\n🚨https://www.twitch.tv/{friend_twitch_channel} 🚨"
            if game_name:
                message += f"\nPlaying: {game_name}"
            message += " 👍"
            await channel.send(message)

            print(f"Twitch API Status Code: {req.status_code}")
            print(f"Twitch API Response: {req.text}")


@tasks.loop(seconds=60)
async def youtubeloop():
    try:
        channel: discord.TextChannel = client.get_channel(youtubeid)
        if channel is None:
            print("Invalid channel configured.")
            return
        try:
            videos = scrapetube.get_channel(
                ytchannel, sort_by="newest", limit=2, content_type="videos")
            time.sleep(1)
            shorts = scrapetube.get_channel(
                ytchannel, sort_by="newest", limit=2, content_type="shorts")
            time.sleep(1)
            lives = scrapetube.get_channel(
                ytchannel, sort_by="newest", limit=2, content_type="streams")
        except Exception as exc:
            print(f"[!] Error: {exc}")
            return

        for results in (videos, shorts, lives):
            for result in results:
                if result['videoId'] not in previous:
                    previous.append(result['videoId'])
                    await channel.send(f"**{channel.guild.default_role} New Upload**\nhttps://www.youtube.com/watch?v={result['videoId']}")
                    print(
                        f"New upload: https://www.youtube.com/watch?v={result['videoId']}")
                    continue
    except Exception as exc:
        print(f"Error: {exc}")


@client.event
async def on_guild_join(guild: discord.Guild):
    await client.tree.sync(guild=guild)


@client.event
async def on_member_join(member: discord.Member):
    welcome = client.get_channel(welcomeid)
    guild = member.guild
    embed = discord.Embed(
        title=f"**╭━━━━━✦WELCOME✦━━━━━━━━━━━━━━━━➧**", colour=client.colour
        ).add_field(name="", value=f"<a:green_crown_sparkle:1105696367667597372> Hello <@{member.id}> <a:green_crown_sparkle:1105696367667597372>", inline=False
                    ).add_field(name="", value=f"<a:green_online:1105696576350978111> Welcome to **{guild.name}** <a:green_online:1105696576350978111>", inline=False
                                ).add_field(name="<a:green_heartstatic:1108584890305351731> Your presence is a valuable addition <a:green_heartstatic:1108584890305351731>", value=f"**━━━━━━━━━━━✦INFO✦━━━━━━━━━━━━━━━━➧**\n<a:green_planet:1105696371631202344> Read our Rules here <#1042619540774846605>\n<a:green_planet:1105696371631202344>  For Help, open a <#1105676532095127643>\n<a:green_planet:1105696371631202344> Customize Your Profile <#1105673962647715951> \n**╰━━━━━━✦ENJOY✦━━━━━━━━━━━━━━━━━━➧**", inline=False)

    background = Editor("Data/welcome.jpg")
    profile_image = await load_image_async(str(member.display_avatar.url))

    profile = Editor(profile_image).resize((250, 250)).circle_image()
    poppins = Font.poppins(size=75, variant="bold")

    poppins_small = Font.poppins(size=50, variant="light")

    background.paste(profile, (390, 50))
    background.ellipse((390, 50), 250, 250, outline="black", stroke_width=4)

    background.text((525, 300), f"WELCOME !", color="white", font=poppins, align="center")
    background.text((525, 360), f"{member.name}", color="white", font=poppins_small, align="center")

    file = discord.File(fp=background.image_bytes, filename="wlcbg.jpg")
    welcome_image = client.get_channel(welcome_image_id)
    message = await welcome_image.send(file=file)
    
    image_url = message.attachments[0].url
    
    embed.set_image(url=image_url)

    await welcome.send(embed=embed)

"""
**╭━━━━━✦WELCOME✦━━━━━━━━━━━━━━━━➧**
> :green_crown_sparkle:Hello <@1138150310435627069> :green_crown_sparkle:
> 📢Welcome to **Lygo's Land** 📢
> ❤️ Your presence is a valuable addition :green_heartstatic:
**━━━━━━━━━━━✦INFO✦━━━━━━━━━━━━━━━━➧**
> 👉🏻 Read our Rules here <#1042619540774846605>
> :green_planet:  For Help, open a <#1105676532095127643>
> :green_planet:  Customize Your Profile <#1105673962647715951>
**╰━━━━━━✦ENJOY✦━━━━━━━━━━━━━━━━━━➧**"""


@client.event
async def setup_hook():
    logs = await client.tree.sync()
    print(f"\033[92m[!]\033[0m \033[94mSynced\033[0m \033[92m{len(logs)}\033[0m \033[94mcommands\033[0m")
    try:
        conn = sqlite3.connect(f"Data/users.db")
        curs = conn.cursor()
        run = "CREATE TABLE IF NOT EXISTS users (userid integer PRIMARY KEY, balance integer, invited integer, left integer, voice integer DEFAULT 0);"
        curs.execute(run)
        run = "CREATE TABLE IF NOT EXISTS warnings (userid integer PRIMARY KEY, reason varchar, warner integer);"
        curs.execute(run)
        run = "CREATE TABLE IF NOT EXISTS giveaways (id integer, ends timestamp, channel integer, message integer, ended integer);"
        curs.execute(run)
        conn.commit()
        conn.close()
        print("\033[92m[!]\033[0m \033[94mUsers Database Connected\033[0m")
    except Exception as exc:
        print(exc)
        quit()


async def loadcogs():
    for files in os.listdir(f'Commands'):
        if files.endswith(".py"):
            await client.load_extension(f'Commands.{files[:-3]}')


async def startup():
    async with client:
        client.sticky = {}
        client.colour = discord.Colour.from_rgb(101, 255, 0)
        client.greenline = "https://i.ibb.co/BVTKyXb/greenline.gif"
        client.modmailid = modmailid
        await loadcogs()
        await client.start(token)


asyncio.run(startup())
